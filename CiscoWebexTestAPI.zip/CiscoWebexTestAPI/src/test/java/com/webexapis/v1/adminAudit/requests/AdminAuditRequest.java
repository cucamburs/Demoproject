package com.webexapis.v1.adminAudit.requests;

public class AdminAuditRequest {
    public void getAdminAudit(){

    }
}
