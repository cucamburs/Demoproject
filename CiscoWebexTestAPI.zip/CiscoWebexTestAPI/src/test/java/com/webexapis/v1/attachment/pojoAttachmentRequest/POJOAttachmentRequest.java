package com.webexapis.v1.attachment.pojoAttachmentRequest;

public class POJOAttachmentRequest {
}
