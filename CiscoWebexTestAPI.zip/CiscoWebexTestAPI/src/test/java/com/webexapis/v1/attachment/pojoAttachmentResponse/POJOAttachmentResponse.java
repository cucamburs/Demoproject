package com.webexapis.v1.attachment.pojoAttachmentResponse;

public class POJOAttachmentResponse {
}
