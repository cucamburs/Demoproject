package com.webexapis.v1.attachment.requests;

public class AttachmentRequest {
}
