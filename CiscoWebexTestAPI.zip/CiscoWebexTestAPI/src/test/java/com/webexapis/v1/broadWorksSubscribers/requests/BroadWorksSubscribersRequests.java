package com.webexapis.v1.broadWorksSubscribers.requests;

public class BroadWorksSubscribersRequests {

    public Object getListSubscribers(){
         // return the API response
        return new Object();
    }

    public Object getSubscribeId(){
        // return the API response
        return new Object();
    }

    public Object postSubscribers(){
        // return the API response
        return new Object();
    }

    public Object putSubscribers(){
        // return the API response
        return new Object();
    }

    public Object deleteSubscribers(){
        // return the API response
        return new Object();
    }
}
