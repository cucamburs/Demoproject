package com.webexapis.v1.deviceConfigurations.pojoDeviceConfigurationsResponse;

public class POJODeviceConfigurationsResponse {
}
