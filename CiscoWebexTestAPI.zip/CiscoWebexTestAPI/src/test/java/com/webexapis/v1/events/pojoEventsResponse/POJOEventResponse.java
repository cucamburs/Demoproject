package com.webexapis.v1.events.pojoEventsResponse;

public class POJOEventResponse {
}
