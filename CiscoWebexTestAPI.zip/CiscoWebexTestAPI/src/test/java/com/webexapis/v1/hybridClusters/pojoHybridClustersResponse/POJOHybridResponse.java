package com.webexapis.v1.hybridClusters.pojoHybridClustersResponse;

public class POJOHybridResponse {
}
