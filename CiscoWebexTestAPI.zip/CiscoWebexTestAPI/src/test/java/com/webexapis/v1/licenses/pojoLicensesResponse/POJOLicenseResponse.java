package com.webexapis.v1.licenses.pojoLicensesResponse;

public class POJOLicenseResponse {
}
