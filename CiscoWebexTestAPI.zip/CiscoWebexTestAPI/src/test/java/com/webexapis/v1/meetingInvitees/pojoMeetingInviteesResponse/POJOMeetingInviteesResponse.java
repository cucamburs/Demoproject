package com.webexapis.v1.meetingInvitees.pojoMeetingInviteesResponse;

public class POJOMeetingInviteesResponse {
}
