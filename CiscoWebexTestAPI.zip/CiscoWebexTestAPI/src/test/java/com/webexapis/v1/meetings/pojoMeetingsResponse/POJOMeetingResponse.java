package com.webexapis.v1.meetings.pojoMeetingsResponse;

public class POJOMeetingResponse {
}
