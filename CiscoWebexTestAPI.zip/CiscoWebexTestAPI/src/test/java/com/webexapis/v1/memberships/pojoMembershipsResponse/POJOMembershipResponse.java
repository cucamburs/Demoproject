package com.webexapis.v1.memberships.pojoMembershipsResponse;

public class POJOMembershipResponse {
}
