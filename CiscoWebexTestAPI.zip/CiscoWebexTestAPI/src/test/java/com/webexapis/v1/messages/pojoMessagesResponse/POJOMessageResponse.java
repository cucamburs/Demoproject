package com.webexapis.v1.messages.pojoMessagesResponse;

public class POJOMessageResponse {
}
