package com.webexapis.v1.mettingPreferences.pojoMettingPreferencesResponse;

public class POJOMettingPreferenceResponse {
}
