package com.webexapis.v1.people.pojoPeopleResponse;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.restassured.response.Response;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.bytebuddy.asm.Advice;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Data
@NoArgsConstructor @AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class POJOPeopleId {


    String id;
//    List<String> emails;
    String displayName;
//    String nickName;
//    String firstName;
//    String lastName;
    String orgId;
/*
    List<String> roles;
    List<String> licenses;
    List<PhoneNumber> phoneNumbers;
    List<SipAddress> sipAddresses;
    Date created;
    Date lastModified;
*/
    String status;
    boolean invitePending;
    boolean loginEnabled;
/*
    String type;
    List<String> siteUrls;
    Date lastActivity;
*/

/*    public class PhoneNumber{
          String type;
        String value;
    }

    public class SipAddress{

        String type;
        String value;
        boolean primary;
    }*/


}




