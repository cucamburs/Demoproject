package com.webexapis.v1.people.pojoPeopleRqParam;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor @AllArgsConstructor
public class POJOPeopleParams {

    private String email;
    private String displayName;
    private String id;
    private String orgId;
    private String localId;

}
