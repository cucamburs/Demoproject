package com.webexapis.v1.people.requests;

import com.webexapis.v1.people.pojoPeopleRqParam.POJOPeopleParams;
import com.webexapis.v1.people.pojoPeopleResponse.POJOPeopleId;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import step_definitions.initalStep.ParamControl;
import utilities.api.APIAuthorization;
import utilities.exeptions.NullParamException;

import java.util.List;

import static io.restassured.RestAssured.given;

public class PeopleRequest {

    private POJOPeopleId peopleId;
    private final POJOPeopleParams peopleParams;

    private RequestSpecification REQ_SPEC = null;


    public PeopleRequest(POJOPeopleParams peopleParams, ParamControl paramControl) {
        System.out.println("This is email " + peopleParams.getEmail());
        try{
            REQ_SPEC =  new RequestSpecBuilder()
                    .setBaseUri((String)paramControl.getParam("RAbaseURI"))
                    .setBasePath("/people")
                    .setContentType(ContentType.JSON)
                    .addParam("email", peopleParams.getEmail())
                    .build();
        } catch(NullParamException npe){
            npe.getMessage();
        }
        this.peopleParams = peopleParams;
    }

    public List<POJOPeopleId> getPeople(){
        List<POJOPeopleId> list = null;

        try{
            Response response = given()
                    .spec(REQ_SPEC)
                    .auth()
                    .oauth2(APIAuthorization.getToken())
                    .get();

            System.out.println(response.statusCode());

            list =  response
                    .jsonPath().getList("items", POJOPeopleId.class);

        }
        catch (Exception e){
            System.out.println("Exception of getPeople " + e.getMessage());
        }
        return list;
    }
    public POJOPeopleId getPeopleId(){

        POJOPeopleId pojoPeopleId;

        pojoPeopleId = given()
                .spec(REQ_SPEC)
                .get("/" + peopleParams.getId()).as(POJOPeopleId.class);


        return pojoPeopleId;
    }



    public Object postPeople(){
        return new Object();
    }

    public Object putPeopleId(){
        return new Object();
    }

    public Object deletePeopleId(){
        return new Object();
    }

    public Object getPeopleMe(){
        return new Object();
    }


}
