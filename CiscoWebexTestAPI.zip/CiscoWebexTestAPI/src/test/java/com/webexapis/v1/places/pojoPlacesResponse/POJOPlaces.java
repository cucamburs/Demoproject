package com.webexapis.v1.places.pojoPlacesResponse;

public class POJOPlaces {
}
