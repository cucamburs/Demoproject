package com.webexapis.v1.recordings.pojoRecordingsResponse;

public class POJOrecordings {
}
