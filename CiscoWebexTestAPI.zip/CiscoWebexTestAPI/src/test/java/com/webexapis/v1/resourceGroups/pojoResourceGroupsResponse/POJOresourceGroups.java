package com.webexapis.v1.resourceGroups.pojoResourceGroupsResponse;

public class POJOresourceGroups {
}
