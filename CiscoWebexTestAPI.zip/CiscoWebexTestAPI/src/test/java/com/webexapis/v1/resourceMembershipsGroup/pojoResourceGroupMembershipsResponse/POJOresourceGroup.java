package com.webexapis.v1.resourceMembershipsGroup.pojoResourceGroupMembershipsResponse;

public class POJOresourceGroup {
}
