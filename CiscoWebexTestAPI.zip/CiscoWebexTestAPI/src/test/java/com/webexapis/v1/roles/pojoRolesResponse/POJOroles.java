package com.webexapis.v1.roles.pojoRolesResponse;

public class POJOroles {
}
