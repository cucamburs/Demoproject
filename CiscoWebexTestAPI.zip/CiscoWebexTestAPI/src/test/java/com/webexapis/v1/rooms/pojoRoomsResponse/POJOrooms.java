package com.webexapis.v1.rooms.pojoRoomsResponse;

public class POJOrooms {
}
