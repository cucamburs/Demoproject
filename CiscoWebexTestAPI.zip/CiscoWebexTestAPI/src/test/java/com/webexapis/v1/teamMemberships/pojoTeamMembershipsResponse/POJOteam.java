package com.webexapis.v1.teamMemberships.pojoTeamMembershipsResponse;

public class POJOteam {
}
