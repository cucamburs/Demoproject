package com.webexapis.v1.teams.pojoTeamsResponse;

public class POJOteams {
}
