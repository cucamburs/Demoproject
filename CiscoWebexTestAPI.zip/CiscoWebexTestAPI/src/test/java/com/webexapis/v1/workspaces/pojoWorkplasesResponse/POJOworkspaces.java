package com.webexapis.v1.workspaces.pojoWorkplasesResponse;

public class POJOworkspaces {
}
