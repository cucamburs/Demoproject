package com.webexapis.v1.xapi.pojoXapiResponse;

public class POJOxapi {
}
