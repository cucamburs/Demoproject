package com.webexuis.v1._generalApp;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import utilities.ui.Driver;

import java.util.ArrayList;
import java.util.HashMap;

public abstract class BasePage implements PageActions{

    // getting singleton WebDriver
    public BasePage() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

}
