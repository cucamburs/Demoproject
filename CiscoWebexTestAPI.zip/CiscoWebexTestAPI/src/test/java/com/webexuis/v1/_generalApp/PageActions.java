package com.webexuis.v1._generalApp;

public interface PageActions {


}
