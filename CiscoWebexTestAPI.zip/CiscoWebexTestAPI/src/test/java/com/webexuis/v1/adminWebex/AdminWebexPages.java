package com.webexuis.v1.adminWebex;

public class AdminWebexPages {

    private LoginPage loginPage;

    public AdminWebexPages() {
        this.loginPage = new LoginPage();
    }

    public LoginPage getLoginPage() {
        return loginPage;
    }
}
