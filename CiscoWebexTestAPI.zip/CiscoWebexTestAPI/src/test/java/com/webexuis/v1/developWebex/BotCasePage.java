package com.webexuis.v1.developWebex;

import com.webexuis.v1.developWebex.pageFrames.DevelopFrame;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.ui.Driver;

public class BotCasePage extends DevelopFrame {

    private WebElement bot;

    private final String HTTPbase = "https://developer.webex.com/my-apps";
    private String HTTP = "";

    @FindBy(xpath = "//span[contains(text(), '@webex.bot')]")
    private WebElement email; // same userName

    public BotCasePage() {
      //  PageFactory.initElements(Driver.getDriver(), this);
    }

    public void initPage(){
        PageFactory.initElements(Driver.getDriver(), this);
    }

    public WebElement getBot(String xpath) {
        if (bot == null)
            this.bot = Driver.getDriver().findElement(By.xpath(xpath));
        return bot;
    }
    public WebElement getEmail() {
        return email;
    }

    public String getHTTP(String botName) {
        if(HTTP.equals(HTTPbase))
            setHTTP(botName);
        return HTTP;
    }

    public void setHTTP(String botName) {
        this.HTTP = HTTPbase + "/" + botName;
    }
}
