package com.webexuis.v1.developWebex;

// class creating of the web application pages
public class DevelopWebexPages {
    public LoginPage loginPage = new LoginPage();
    public GettingStartedPage gettingStartedPage = new GettingStartedPage();
    public WelcomePage welcomePage = new WelcomePage();
    public DocumentationPages documentationPages = new DocumentationPages();
    public OverviewBotsPage overviewBots = new OverviewBotsPage();
    public NewBotCongratulation newBotCongratulation = new NewBotCongratulation();
    public MyAppsPage myAppsPage = new MyAppsPage();
    public BotCasePage botCasePage = new BotCasePage();
    public NewBotPage newBot = new NewBotPage();

}

