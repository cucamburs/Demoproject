package com.webexuis.v1.developWebex;

import com.webexuis.v1.developWebex.pageFrames.DocumentationPageFrame;
import org.openqa.selenium.support.PageFactory;
import utilities.ui.Driver;

public class DocumentationPages extends DocumentationPageFrame {

    public DocumentationPages() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    public final String HTTP = "https://developer.webex.com/docs/platform-introduction";

    public void initPage(){PageFactory.initElements(Driver.getDriver(), this);}

}
