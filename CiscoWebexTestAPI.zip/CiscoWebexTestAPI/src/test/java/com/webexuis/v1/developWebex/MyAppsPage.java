package com.webexuis.v1.developWebex;

import com.webexuis.v1.developWebex.pageFrames.DevHeader;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.ui.Driver;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MyAppsPage extends DevHeader {

    private final String HTTP = "https://developer.webex.com/my-apps";

    private String param;

    private WebElement bot;

    @FindBy(xpath = "//h3[contains(text(), 'My Apps')]")
    private WebElement myAppsText;

    @FindBy(xpath = "//a[@data-app-id]")
    private List<WebElement> appElements;

    private WebElement appElement;


    public MyAppsPage() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    public MyAppsPage(String param) {
        PageFactory.initElements(Driver.getDriver(), this);
        this.param = param;
    }

    public WebElement getBot(String xpath) {
        if (bot == null)
            this.bot = Driver.getDriver().findElement(By.xpath(xpath));
        return bot;
    }

    public String getHTTP() {
        return HTTP;
    }

    public WebElement getMyAppsText() {
        return myAppsText;
    }

    public List<WebElement> getBots(){

        return new ArrayList<WebElement>();
    }

    public List<WebElement> getAppElements() {
        return appElements;
    }

    public boolean setElementFromListAppElements(String userApp){

        for (WebElement element : appElements) {
            if (element.getAttribute("href").contains(userApp.toLowerCase(Locale.ROOT))){
                this.appElement = element;
                return true;
            }

        }
    return false;
    }

    public WebElement getAppElement() {
        return appElement;
    }

    public void setAppElement(WebElement appElement) {
        this.appElement = appElement;
    }


}
