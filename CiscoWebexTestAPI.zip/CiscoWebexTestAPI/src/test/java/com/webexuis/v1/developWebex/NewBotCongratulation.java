package com.webexuis.v1.developWebex;

import com.webexuis.v1.developWebex.pageFrames.DevelopFrame;
import com.webexuis.v1.developWebex.pageFrames.DocumentationPageFrame;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.ui.Driver;

public class NewBotCongratulation extends DevelopFrame {

    public NewBotCongratulation() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(xpath = "//h1[contains(text(), 'Congratulations!')]")
    private WebElement congratulationText;

    public WebElement getCongratulationText() {
        return congratulationText;
    }
}
