package com.webexuis.v1.developWebex;

import com.webexuis.v1.developWebex.pageFrames.DevelopFrame;
import io.cucumber.datatable.DataTable;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import step_definitions.libraryOfapplications.develop.steps.BotCreating;
import utilities.exeptions.BotException;
import utilities.ui.Driver;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Map;

public class NewBotPage extends DevelopFrame {

    public NewBotPage() {
        PageFactory.initElements(Driver.getDriver(), this);}

    @FindBy(xpath = "//h2[contains(text(), 'New Bot')]")
    private WebElement h2NewBot;

    // index 0
    @FindBy(name = "name")
    private WebElement name;
    // index 1
    @FindBy(name = "_botEmail")
    private WebElement botEmail;

    // index 2
    @FindBy(xpath = "//*[@data-preset='image-selector-preset-0']")
    private WebElement icon1;
    @FindBy(xpath = "//*[@data-preset='image-selector-preset-1']")
    private WebElement icon2;
    @FindBy(xpath = "//*[@data-preset='image-selector-preset-2']")
    private WebElement icon3;

    // index 3
    @FindBy(name = "description")
    private WebElement description;

    @FindBy(className = "md-button")
    private WebElement buttonCancel;

    @FindBy(id = "add-bot-submit-button")
    private WebElement buttonAddBot;

    @FindBy(xpath = "//dev[contains(@class, 'md-alert')]")
    private WebElement alertForm;




    public void createBot(DataTable table){

       try{
           for (Map<Object, Object> bot : table.asMaps(String.class, String.class)) {

               try {
                   if (bot.get("name") == null || bot.get("email") == null || bot.get("icon") == null)
                       throw new BotException();


                   this.name.sendKeys((String) bot.get("name"));
                   this.botEmail.sendKeys((String) bot.get("email"));
                   this.botEmail.sendKeys(Keys.TAB);

                   switch ((String) bot.get("icon")) {
                       case "Default1":
                           icon1.click();
                           break;
                       case "Default2":
                           icon2.click();
                           break;
                       case "Default3":
                           icon3.click();
                   }
                   Thread.sleep(3000);
                   description.sendKeys(bot.get("description").toString());

                   if (Driver.getDriver().findElement(By.className("message")).isDisplayed())
                       System.out.println("test");//throw new BotException();
               } catch (BotException be) {
                    be.getMessage(bot.get("email") + "@webex.bot");
               } catch (InterruptedException e) {
                   throw new RuntimeException(e);
               }

           }
       }catch (Exception e){
           e.getMessage();
       }
/*       catch (BotException botException){
           System.out.println(botException.getMessage());
       }*/
        this.buttonAddBot.click();
    }

    public WebElement getH2NewBot() {
        return h2NewBot;
    }

    public WebElement getName() {
        return name;
    }

    public WebElement getBotEmail() {
        return botEmail;
    }

    public WebElement getIcon1() {
        return icon1;
    }

    public WebElement getIcon2() {
        return icon2;
    }

    public WebElement getIcon3() {
        return icon3;
    }

    public WebElement getDescription() {
        return description;
    }

    public WebElement getButtonCancel() {
        return buttonCancel;
    }

    public WebElement getButtonAddBot() {
        return buttonAddBot;
    }
}
