package com.webexuis.v1.developWebex;

import com.webexuis.v1.developWebex.pageFrames.TwitterWidget;
import com.webexuis.v1.developWebex.pageFrames.WelcomePageFrame;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.ui.Driver;

public class WelcomePage extends WelcomePageFrame {
    private TwitterWidget twitterWidget;
    public WelcomePage() {
        twitterWidget = new TwitterWidget();
        PageFactory.initElements(Driver.getDriver(), this);
    }

    public final String HTTP = "https://developer.webex.com/";

    //---------------------

    @FindBy(xpath = "//a/span[text()='Start Building Apps']")
    public WebElement aStartBuildingApps;

    @FindBy(xpath = "//a/span[text()='Go to Docs']")
    public WebElement aGoToDocs;

    //---------------------
    @FindBy(xpath = "//*[@class='md-list-item' and @href='/docs/platform-introduction']")
    public WebElement documentation;

    @FindBy(xpath = "//a//h3/span[text()='Bots']")
    public WebElement aBots;

    @FindBy(xpath = "//a//h3/span[text()='Integrations']")
    public WebElement aIntegrations;

    @FindBy(xpath = "//a//h3/span[text()='Widgets']")
    public WebElement aWidgets;

    @FindBy(xpath = "//a//h3/span[text()='Admin APIs']")
    public WebElement aAdminAPIs;

    public WebDriver getDriver(){
        return Driver.getDriver();
    }
    //----------- Twitter Frame --------------//

    public void switchToTwitterFrame(){
        twitterWidget.switchToFrame();
    }

    public WebElement getTwitterWidgetItem(int index) {
       return twitterWidget.getTwitterItem(index);
    }

    //----------------End Twitter Frame----------

    public void goToMyApps(){
        devHeader.goToMyApp();
    }

    public void goToWelcomePage(){
        Driver.getDriver().get(HTTP);
        initPage();
    }

    public void initPage(){
        devHeader.initPage();
        PageFactory.initElements(Driver.getDriver(), this);
    }

}
