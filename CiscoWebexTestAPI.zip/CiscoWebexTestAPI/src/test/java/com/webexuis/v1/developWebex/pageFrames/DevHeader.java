package com.webexuis.v1.developWebex.pageFrames;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.ui.Driver;

public class DevHeader {



    public DevHeader(){
        PageFactory.initElements(Driver.getDriver(), this);
    }

    private final IconMenu iconMenu = new IconMenu();

    @FindBy(id = "header-login-link")
    private WebElement logIn;

/*    @FindBy(id = "header-logout-link")
    private WebElement logOut;*/

/*    @FindBy(className = "md-top-bar__user")
    private WebElement userAvatar;*/

/*    @FindBy(className = "md-avatar__letter user-image")
    private WebElement avatar;*/

    public WebElement getLogIn() {

        return logIn;
    }

/*    public WebElement getUserAvatar() {
        return userAvatar;
    }*/

    public IconMenu getIconMenu() {
        return iconMenu;
    }

    /*    public WebElement getLogOut() {
        return logOut;
    }

    public WebElement getAvatar() {
        return avatar;
    }*/

    public void goToMyApp(){
        getIconMenu().getUserAvatar().click();
        getIconMenu().getMyWebexApp().click();
    }


    public void initPage(){
        iconMenu.init();
        PageFactory.initElements(Driver.getDriver(), this);
    }
}
