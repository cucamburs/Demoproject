package com.webexuis.v1.developWebex.pageFrames;

public class DevelopFrame {
    public DevHeader devHeader = new DevHeader();
    public DevFooter devFooter = new DevFooter();


}
