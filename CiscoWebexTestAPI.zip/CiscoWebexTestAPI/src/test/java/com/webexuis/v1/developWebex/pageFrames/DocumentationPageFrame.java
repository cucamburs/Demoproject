package com.webexuis.v1.developWebex.pageFrames;

public class DocumentationPageFrame {

    public DevHeader devHeader = new DevHeader();
    public DevFooter devFooter = new DevFooter();
    public SideMenu sideMenu = new SideMenu();

}
