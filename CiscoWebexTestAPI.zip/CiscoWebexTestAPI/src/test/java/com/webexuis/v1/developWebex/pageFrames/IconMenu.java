package com.webexuis.v1.developWebex.pageFrames;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.ui.Driver;

public class IconMenu {


    public IconMenu() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(xpath = "//a[@class='md-list-item']/span[contains(text(), 'My Webex Apps')]")
    private WebElement myWebexApp;

    @FindBy(className = "md-avatar")
    private WebElement userAvatar;

    public WebElement getMyWebexApp() {
        return myWebexApp;
    }

    public WebElement getUserAvatar() {
        return userAvatar;
    }

    public void init(){PageFactory.initElements(Driver.getDriver(), this);}
}
