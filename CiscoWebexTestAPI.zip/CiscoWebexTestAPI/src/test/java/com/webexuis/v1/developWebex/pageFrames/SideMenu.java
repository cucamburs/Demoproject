package com.webexuis.v1.developWebex.pageFrames;

import com.webexuis.v1._generalApp.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.ui.Driver;

// Frame for all application pages. Similar class is in each web application.
// Class contains same elements for all pages of web application
// for example: side menu, header, footer
// I tried to separate each element of the pages (side menu, header, footer in the separate class, but
// multiple inheritance is prohibited in Java so solution for it is searched)

public class SideMenu extends BasePage {

        public SideMenu(){
        PageFactory.initElements(Driver.getDriver(), this);
    }
    // ===========      =================   SideMenu   ================       =================  //

    @FindBy(xpath = "//*[@class='page-content-wrapper']//div[contains (@class, 'md-sidebar__header') and contains(text(),'Build')]")
    private WebElement textOverview;

    @FindBy(xpath = "//*[@class='page-content-wrapper']//a[@href='/docs/platform-introduction']")
    private WebElement menuOverviewPlatformIntrodution;

    @FindBy(xpath = "//*[contains(@class, 'md-list md-list--vertical')]//a[@href='/docs/bots']")
    private WebElement menuOverviewBots;

    @FindBy(xpath = "//*[@class='page-content-wrapper']//a[@href='/docs/integrations']")
    private WebElement menuOverviewIntegrations;

    @FindBy(xpath = "//*[@class='page-content-wrapper']//a[@href='/docs/widgets']")
    private WebElement menuOverviewWidgets;

    @FindBy(xpath = "//*[@class='page-content-wrapper']//a[@class='md-submenu__item' and @href='/docs/guest-issuer']")
    private WebElement menuOverviewGuestIssuer;

    @FindBy(xpath = "//*[@class='page-content-wrapper']//a[@href='/docs/api/getting-started']")
    private WebElement menuApiGettingStarted;

    @FindBy(xpath = "//*[@class='page-content-wrapper']//a[@href='/docs/api/basics']")
    private WebElement menuApiBasics;

    @FindBy(xpath = "//*[@class='page-content-wrapper']//div[@class='md-list-item active']")
    private WebElement menuApiGuides;

    @FindBy(xpath = "//*[@class='page-content-wrapper']//div[@id='md-sidebar__nav-item-2-4']")
    private WebElement menuApiAPIReference;

// ================== Start Group menu People ========================//
        @FindBy(xpath = "//*[@class='page-content-wrapper']//a[@href='/docs/api/v1/people']")
        private WebElement menuApiAPIReferencePeople;

        @FindBy(xpath = "//div[@class='md-list md-list--vertical md-submenu menu-People']//a[@href='/docs/api/v1/people/list-people']")
            private WebElement menuApiAPIReferencePeopleGetList;
    // ================== End Group menu People ========================//

    @FindBy(xpath = "//*[@class='page-content-wrapper']//a[@href='/docs/api/changelog']")
    private WebElement menuApiAPIChangelog;

    // Getters


    public WebElement getTextOverview() {
        return textOverview;
    }

    public WebElement getMenuOverviewPlatformIntrodution() {
        return menuOverviewPlatformIntrodution;
    }

    public WebElement getMenuOverviewBots() {
        return menuOverviewBots;
    }

    public WebElement getMenuOverviewIntegrations() {
        return menuOverviewIntegrations;
    }

    public WebElement getMenuOverviewWidgets() {
        return menuOverviewWidgets;
    }

    public WebElement getMenuOverviewGuestIssuer() {
        return menuOverviewGuestIssuer;
    }

    public WebElement getMenuApiGettingStarted() {
        return menuApiGettingStarted;
    }

    public WebElement getMenuApiBasics() {
        return menuApiBasics;
    }

    public WebElement getMenuApiGuides() {
        return menuApiGuides;
    }

    public WebElement getMenuApiAPIReference() {
        return menuApiAPIReference;
    }

    public WebElement getMenuApiAPIReferencePeople() {
        return menuApiAPIReferencePeople;
    }

    public WebElement getMenuApiAPIReferencePeopleGetList() {
        return menuApiAPIReferencePeopleGetList;
    }

    public WebElement getMenuApiAPIChangelog() {
        return menuApiAPIChangelog;
    }

    //  Page Initialization

    public void initPage(){PageFactory.initElements(Driver.getDriver(), this);}
}
