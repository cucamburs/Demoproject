package com.webexuis.v1.developWebex.pageFrames;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import utilities.ui.Driver;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;

public class TwitterWidget  {

    private List<WebElement> twittSet;

    public TwitterWidget() {

    }

    public void switchToFrame(){
        Driver.getDriver().switchTo().frame("twitter-widget-0");
        if(twittSet == null)
            twittSet = Driver.getDriver().findElements(By.xpath("//li[@class='timeline-TweetList-tweet customisable-border']/div"));
    }

    public void clickOnItem(int index) {
        try {
            twittSet.get(index).click();
        } catch (NullPointerException npi) {
            System.out.println("Twitter widget is empty");
        }
    }

    public int getTwittSetSize(){
        return twittSet.size();
    }

    public WebElement getTwitterItem(int index){
        try {
            return twittSet.get(index);
        } catch (NullPointerException npi) {
            System.out.println("Twitter widget is empty");
        }
        return null;
    }

    /*
    public List<WebElement> getTwittSet() {
        return twittSet;
    }
*/


}
