package com.webexuis.v1.developWebex.pageFrames;

import com.webexuis.v1._generalApp.BasePage;

public class WelcomePageFrame extends BasePage {

    public DevHeader devHeader = new DevHeader();
   // protected final TwitterWidget twitterWidget = new TwitterWidget();
}
