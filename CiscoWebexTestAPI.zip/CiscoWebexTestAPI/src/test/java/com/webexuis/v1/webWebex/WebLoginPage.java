package com.webexuis.v1.webWebex;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.ui.BrowserUtils;
import utilities.ui.Driver;

public class WebLoginPage {

    public WebLoginPage() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    public final String HTTP = "https://web.webex.com/";

    @FindBy(className = "md-input")
    public WebElement credentials;

    @FindBy(id = "md-button-3")
    public WebElement buttonNext;

    @FindBy(id = "Button1")
    public WebElement buttonSignIn;

    @FindBy(className="login-onboarding-layout-title")
    public WebElement labelSignInUp;

    public WebDriver getDriver(){
        return Driver.getDriver();
    }

    public void logIn(String email, String password) {
        //Driver.getDriver().get(HTTP);
        BrowserUtils.waitForVisibility(buttonNext,3);
        credentials.sendKeys(email);
        buttonNext.click();
        BrowserUtils.waitForVisibility(buttonSignIn,7);
        credentials.sendKeys(password);
        buttonSignIn.click();

    }

}
