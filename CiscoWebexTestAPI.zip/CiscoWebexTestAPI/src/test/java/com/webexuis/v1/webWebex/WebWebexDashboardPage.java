package com.webexuis.v1.webWebex;

import com.webexuis.v1.webWebex.pageFrames.WebWebexFrame;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import utilities.ui.Driver;

public class WebWebexDashboardPage extends WebWebexFrame {

    public WebDriver getDriver(){
        return Driver.getDriver();
    }

    public void init(){
        PageFactory.initElements(Driver.getDriver(), this);
    }

}
