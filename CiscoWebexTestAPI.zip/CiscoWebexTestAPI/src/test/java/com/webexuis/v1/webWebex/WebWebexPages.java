package com.webexuis.v1.webWebex;

import com.webexuis.v1.developWebex.LoginPage;
import com.webexuis.v1.webWebex.pageFrames.WebWebexFrame;

public class WebWebexPages {

    public WebLoginPage webLoginPage = new WebLoginPage();
    public WebWebexDashboardPage webexDashboardPage = new WebWebexDashboardPage();

}
