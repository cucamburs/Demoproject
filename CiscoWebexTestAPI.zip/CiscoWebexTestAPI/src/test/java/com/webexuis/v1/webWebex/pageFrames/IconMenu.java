package com.webexuis.v1.webWebex.pageFrames;

import com.webexuis.v1._generalApp.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.ui.Driver;

public class IconMenu {
    public IconMenu() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(xpath = "//button[contains(@class, 'reset-button')]")
    public WebElement userAvatar;

    @FindBy(id = "md-menu-item-7")
    public WebElement signOut;

}
