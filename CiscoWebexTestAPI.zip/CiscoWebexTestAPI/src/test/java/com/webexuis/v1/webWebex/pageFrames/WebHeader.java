package com.webexuis.v1.webWebex.pageFrames;

import com.webexuis.v1._generalApp.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class WebHeader {

    private IconMenu iconMenu;

    public IconMenu getIconMenu() {
        return new IconMenu();
    }
}
