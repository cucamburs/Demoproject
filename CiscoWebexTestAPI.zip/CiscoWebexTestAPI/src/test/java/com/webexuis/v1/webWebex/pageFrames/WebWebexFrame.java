package com.webexuis.v1.webWebex.pageFrames;

public class WebWebexFrame {
    public WebHeader webHeader = new WebHeader();
}
