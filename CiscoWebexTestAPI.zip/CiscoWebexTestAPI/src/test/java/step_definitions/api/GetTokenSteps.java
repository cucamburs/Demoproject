package step_definitions.api;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import org.testng.annotations.Test;
import step_definitions.libraryOfapplications.develop.initial.DevelopBaseSteps;
import utilities.api.APIAuthorization;
import utilities.dataControl.fileReaders.TextReaderUtility;
import utilities.dictionary.DirectoryType;
import utilities.exeptions.NullAppException;
import utilities.exeptions.NullParamException;
import utilities.exeptions.NullUserNameException;
import utilities.generalUtilities.DeleteDirectory;
import utilities.generalUtilities.Git;
import utilities.generalUtilities.GitControl;
import utilities.ui.BrowserUtils;
import utilities.ui.Driver;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;


import static io.restassured.RestAssured.given;

public class GetTokenSteps extends DevelopBaseSteps {

    public GetTokenSteps() throws NullAppException, NullUserNameException, NullParamException {
    }


    @When("I go to TokenPage")
    public void i_go_to_TokenPage() {
        try {
            Driver.getDriver().get((String)paramControl.getParam("token_base_url"));
        } catch (NullParamException e) {
            e.printStackTrace();
        }
      /*  Assertions.assertTrue(developWebexPages.gettingStartedPage.bodyTokenButton.isDisplayed());*/

    }
    @And("I take Token")
    public void itakeToken() throws InterruptedException {
        developWebexPages.gettingStartedPage.bodyTokenButton.click();
        BrowserUtils.waitForVisibility(developWebexPages.gettingStartedPage.bodyTokenButton,3);
        developWebexPages.gettingStartedPage.okButton.click();
        Thread.sleep(3000);
        APIAuthorization.setToken(BrowserUtils.copyFromBuffer());

        //Assertions.assertFalse(APIAuthorization.getToken().isEmpty());
    }

    @And("I save it to the file")
    public void i_save_it_to_the_file() throws IOException {

        File directory = new File(String.valueOf(GitControl.getDirectory(paramControl, DirectoryType.directory)));

        if (directory.exists())
            try{
                DeleteDirectory.delete(directory);

            }catch(IOException e){
                e.printStackTrace();
                System.exit(0);
            }

        Files.createDirectories(GitControl.getDirectory(paramControl, DirectoryType.directory));

        Files.write(GitControl.getDirectory(paramControl, DirectoryType.directory).resolve("token.txt"), BrowserUtils.copyFromBuffer().getBytes());
    }

    @And("Push to the remote repository")
    public void push_to_the_remote_repository()  {
        System.out.println("Start push");
        try{
     //       System.out.println("kill agent start");
     //       Git.githubKillAgent(paramControl);
            System.out.println("Start agent");
            Git.githubAgentAdd(paramControl);
            System.out.println("kill agent start");
            Git.githubKillAgent(paramControl);
            System.out.println("Start Add the path to agent ");
            Git.githubSSHKeyAdd(paramControl);
            System.out.println("Test connect by SSH key");
            Git.githubTestConnection(paramControl);
            System.out.println("All completed");
        }catch (IOException | InterruptedException e){
            e.printStackTrace();
        }




/*        GitControl.getInitToken(paramControl);

        GitControl.gitRemoteAddRepo(paramControl);

        GitControl.gitSetRepo(paramControl);

        GitControl.addToken(paramControl);

        GitControl.commitToken(paramControl, "next commit of token key");

        GitControl.pushForceToken(paramControl);*/


    }
}



