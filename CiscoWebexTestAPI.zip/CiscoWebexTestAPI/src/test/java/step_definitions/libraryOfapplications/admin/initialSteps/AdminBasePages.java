package step_definitions.libraryOfapplications.admin.initialSteps;

public class AdminBasePages {
}
