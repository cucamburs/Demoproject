package step_definitions.libraryOfapplications.admin.steps;

import step_definitions.libraryOfapplications.admin.initialSteps.AdminBaseSteps;
import utilities.exeptions.NullAppException;
import utilities.exeptions.NullParamException;
import utilities.exeptions.NullUserNameException;

public class LoginStepDef extends AdminBaseSteps {

    public LoginStepDef() throws NullAppException, NullUserNameException, NullParamException {
        super();
    }

}
