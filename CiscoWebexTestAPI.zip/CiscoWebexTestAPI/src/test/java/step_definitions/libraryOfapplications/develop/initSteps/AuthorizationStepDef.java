package step_definitions.libraryOfapplications.develop.initSteps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import org.testng.annotations.Test;
import step_definitions.initalStep.BaseStep;
import step_definitions.libraryOfapplications.develop.initial.DevelopBaseSteps;
import utilities.api.APIAuthorization;
import utilities.dataControl.fileReaders.TextReaderUtility;
import utilities.dictionary.DirectoryType;
import utilities.exeptions.NullAppException;
import utilities.exeptions.NullParamException;
import utilities.exeptions.NullUserNameException;
import utilities.generalUtilities.GitControl;
import utilities.ui.Driver;

import static io.restassured.RestAssured.given;


public class AuthorizationStepDef extends DevelopBaseSteps {

    public AuthorizationStepDef() throws NullAppException, NullUserNameException, NullParamException {
    }

    @Test
    @Given("I read the API token from the file")
    public void iReadAPIToken(){
        APIAuthorization.setToken(new TextReaderUtility(String.valueOf(GitControl.getDirectory(paramControl, DirectoryType.directory))).getStringResult());
    }

    @Test
    @Given("I am checking Token to take Token")
    public void i_am_checking_token_to_take_token() {
        System.out.println("Just simple test!!!");

/*        Assertions.assertTrue(true);
        if(APIAuthorization.getToken() != null)
            // checking current Token. Token has 12 hours life, therefore it may be overdue
            Assertions.assertEquals(given().
                    header("Authorization", APIAuthorization.getToken()).
                    log().all().
                    when().
                    get(EndPoints.organizations.getEndpoint()).getStatusCode(), 401);
        // for reporting. It is always TRUE
        else Assertions.assertNull(APIAuthorization.getToken());*/

    }

    @Given("I have the API token")
    public void i_have_the_api_token() {
        given()
                .header("Authorization", "Bearer" + APIAuthorization.getToken())
                .when()
                .get("/organizations")
                .then()
                .statusCode(200);
    }

    @And("Complete Tests")
    public void completeTests(){
        Driver.getDriver().quit();
        Driver.closeDriver();
    }

}
