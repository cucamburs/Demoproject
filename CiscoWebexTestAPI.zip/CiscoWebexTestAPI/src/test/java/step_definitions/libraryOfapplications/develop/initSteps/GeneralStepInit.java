package step_definitions.libraryOfapplications.develop.initSteps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import step_definitions.initalStep.BaseStep;
import step_definitions.libraryOfapplications.develop.initial.DevelopBaseSteps;
import utilities.exeptions.NullAppException;
import utilities.exeptions.NullParamException;
import utilities.exeptions.NullUserNameException;
import utilities.ui.Driver;

public class GeneralStepInit extends DevelopBaseSteps {

    public GeneralStepInit() throws NullAppException, NullUserNameException, NullParamException {
    }

    @Then("I get Welcome Page")
    public void iGetWelcomePage() {

        Driver.getDriver().get(developWebexPages.welcomePage.HTTP);
        developWebexPages.welcomePage.initPage();
        Assertions.assertTrue(developWebexPages.welcomePage.devHeader.getIconMenu().getUserAvatar().isDisplayed());
    }

    @And("I get API documentation")
    public void iAmGoingToAPIDocumentation() {
        Driver.getDriver().get(developWebexPages.documentationPages.HTTP);
        Assertions.assertTrue(developWebexPages.documentationPages.sideMenu.getTextOverview().isDisplayed());
    }

}
