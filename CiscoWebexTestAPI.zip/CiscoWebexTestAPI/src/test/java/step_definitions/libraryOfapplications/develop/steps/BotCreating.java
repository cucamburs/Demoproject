package step_definitions.libraryOfapplications.develop.steps;


import com.webexapis.v1.people.pojoPeopleRqParam.POJOPeopleParams;
import com.webexapis.v1.people.pojoPeopleResponse.POJOPeopleId;
import com.webexapis.v1.people.requests.PeopleRequest;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.Test;
import step_definitions.libraryOfapplications.develop.initial.DevelopBaseSteps;
import utilities.exeptions.NullAppException;
import utilities.exeptions.NullParamException;
import utilities.exeptions.NullUserNameException;
import utilities.ui.Driver;

import java.util.List;
import java.util.Locale;


public class BotCreating extends DevelopBaseSteps {


    public BotCreating() throws NullAppException, NullUserNameException, NullParamException {
    }

    @Test
    @When("I fill up Bot details bot and I create Bot")
    public void iFillUpBotDetailsBotAndICreateBot(DataTable table) {
        // conditions: side menu is available
        developWebexPages.documentationPages.sideMenu.getMenuOverviewBots().click();
        // conditions: passed parameters for creating Bot otherwise have BotException
        developWebexPages.overviewBots.getButton_CreateABot().click();
        developWebexPages.newBot.createBot(table);
    }

    // @Then("^I check Bot ([^\"]*)$")
    @Test
    @Then("^I check Bot")
    public void i_check_bot(String name) {
        try{
            developWebexPages.myAppsPage.getMyAppsText().getText();
        }catch(NoSuchElementException noSuchElementException){
            Driver.getDriver().get(developWebexPages.myAppsPage.getHTTP());
        }
        Assertions.assertEquals("My Apps", developWebexPages.myAppsPage.getMyAppsText().getText(),
                "Web Element has not been found or Web page has not been downloaded");

        developWebexPages.myAppsPage.setElementFromListAppElements(name);
        developWebexPages.myAppsPage.getAppElement().click();
        developWebexPages.botCasePage.setHTTP(name.toLowerCase(Locale.ROOT));
        developWebexPages.botCasePage.initPage();

        POJOPeopleParams peopleParams = new POJOPeopleParams();
        System.out.println("test point kiselev");
        peopleParams.setEmail(developWebexPages.botCasePage.getEmail().getText());
        PeopleRequest peopleRequest = new PeopleRequest(peopleParams, paramControl);

        List<POJOPeopleId> people = peopleRequest.getPeople();
        for (POJOPeopleId person : people) {
            Assertions.assertEquals(person.getDisplayName(), name, "the bot " + name + "is not found");

        }



    }
}

