package step_definitions.libraryOfapplications.develop.steps;

import io.cucumber.java.en.When;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import step_definitions.libraryOfapplications.develop.initial.DevelopBaseSteps;
import utilities.exeptions.NullAppException;
import utilities.exeptions.NullParamException;
import utilities.exeptions.NullUserNameException;
import utilities.ui.Driver;

import java.util.ArrayList;

public class WelcomePageSteps extends DevelopBaseSteps {

    public WelcomePageSteps() throws NullAppException, NullUserNameException, NullParamException {
    }

    @Test
    @When("^I go to Welcome page$")
    public void iGoToWelcomePage(){

        String tempHandle = Driver.getDriver().getWindowHandle();

        developWebexPages.welcomePage.goToWelcomePage();
        Assertions.assertTrue(developWebexPages.welcomePage.aStartBuildingApps.isDisplayed());

        // Assertion step one


        // Welcome page contained a widget and below is actions with the widget and a browser windows (tabs) 02.16.2023

        /*
                                it's out of date

        developWebexPages.welcomePage.switchToTwitterFrame();
        String twitHttp = developWebexPages.welcomePage.getTwitterWidgetItem(0).getAttribute("data-click-to-open-target");
        developWebexPages.welcomePage.getTwitterWidgetItem(0).click();
        developWebexPages.welcomePage.getTwitterWidgetItem(0).click();

        ArrayList<String> tabs = new ArrayList<String>(Driver.getDriver().getWindowHandles());

        for (String tab : tabs) {
            if (!tempHandle.equals(tab)){
                Driver.getDriver().switchTo().window(tab);
                Driver.getDriver().get(twitHttp);
                Assertions.assertTrue(Driver.getDriver().getCurrentUrl().startsWith("https://twitter.com/"));
                break;
            }
        }

        for (String tab : Driver.getDriver().getWindowHandles()){
            if (!tempHandle.equals(tab)){
                Driver.getDriver().switchTo().window(tab);
                Driver.getDriver().close();
            }
        }

        Driver.getDriver().switchTo().window(tempHandle);

        */
    }

}
