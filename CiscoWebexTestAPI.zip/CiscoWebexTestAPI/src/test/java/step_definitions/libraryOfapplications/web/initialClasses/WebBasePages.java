package step_definitions.libraryOfapplications.web.initialClasses;

public class WebBasePages {
}
