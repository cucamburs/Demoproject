package step_definitions.libraryOfapplications.web.initialClasses;

import com.webexuis.v1.webWebex.WebWebexPages;
import step_definitions.initalStep.BaseStep;
import utilities.exeptions.NullAppException;
import utilities.exeptions.NullParamException;
import utilities.exeptions.NullUserNameException;

public class WebBaseSteps extends BaseStep {

    protected WebWebexPages webWebexPages;

    public WebBaseSteps() throws NullAppException, NullUserNameException, NullParamException {
        authentication = new WebAuthentication(paramControl);
        webWebexPages = pages.getWebWebexPages();
    }
}
