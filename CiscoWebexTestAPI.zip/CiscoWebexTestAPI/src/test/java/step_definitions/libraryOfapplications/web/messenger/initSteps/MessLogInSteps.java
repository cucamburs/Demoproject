package step_definitions.libraryOfapplications.web.messenger.initSteps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.Alert;
import step_definitions.libraryOfapplications.web.initialClasses.WebBaseSteps;
import utilities.exeptions.NullAppException;
import utilities.exeptions.NullParamException;
import utilities.exeptions.NullUserNameException;
import utilities.ui.BrowserUtils;
import utilities.ui.Driver;

public class MessLogInSteps extends WebBaseSteps {


    public MessLogInSteps() throws NullAppException, NullUserNameException, NullParamException {
    }

    @Test
    @Given("^I start app web$")
    public void iAmGoingToAppWeb(){
        try {
            Driver.getDriver().get((String) paramControl.getParam("base_url"));
        } catch (NullParamException e) {
            e.printStackTrace();
        }
        //Driver.getDriver().get(webWebexPages.webLoginPage.HTTP);
        Assertions.assertTrue(webWebexPages.webLoginPage.labelSignInUp.isDisplayed());
    }

    @Test
    @And("^([^\"]*) is going to webex login page$")
    public void userIsOnWebexLoginPage(String userName) {
        webWebexPages.webLoginPage.getDriver().get(webWebexPages.webLoginPage.HTTP);
        Assertions.assertTrue(webWebexPages.webLoginPage.labelSignInUp.isDisplayed());
    }

    @Test
    @When("^([^\"]*) is passing authentication for webex app")
    public void userIsPassingAuthenticationForWebex_app(String userName) throws InterruptedException {
        try {
            webWebexPages.webLoginPage.
                    logIn(
                            (String)paramControl.getParam(userName+".Email"),
                            (String)paramControl.getParam(userName+".Pass")
                    );
        } catch (NullParamException e) {
            e.printStackTrace();
        }

        Thread.sleep(10000);

       Assertions.assertTrue(webWebexPages.webexDashboardPage.webHeader.getIconMenu().userAvatar.isDisplayed());

    }
    @Test
    @Then("^([^\"]*) on webex welcome page")
    public void UserOnWebexWelcomePage(String param) {
        System.out.println(param);
    }
}
