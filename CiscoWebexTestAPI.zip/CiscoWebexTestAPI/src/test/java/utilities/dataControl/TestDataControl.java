package utilities.dataControl;

public class TestDataControl {


    public Object setData(){

        return new Object();
    }
}
