package utilities.dataControl.dataSource;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public abstract class DataSource {

    private StringBuilder sb;
    protected Object resultObj;
    protected Object accessObj;

    public void readFromFile(String path){

        sb = new StringBuilder();

        try (BufferedReader reader = Files.newBufferedReader(Paths.get(path))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append(System.lineSeparator());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public abstract <T> T getData(Object obj, Class<T> tClass);

    public StringBuilder getSb() {
        return sb;
    }
}
