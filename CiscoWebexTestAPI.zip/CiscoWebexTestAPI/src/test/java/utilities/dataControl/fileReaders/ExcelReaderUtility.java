package utilities.dataControl.fileReaders;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import utilities.dataControl.dataSource.DataSource;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;


public class ExcelReaderUtility extends DataSource {

    public HSSFWorkbook workbook;

    @Override
    public <T> T getData(Object obj, Class<T> tClass) {
        return null;
    }
}
