package utilities.dataControl.fileReaders;

import utilities.dataControl.dataSource.DataSource;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class TextReaderUtility extends DataSource {

    private String stringResult;

    public TextReaderUtility(String path) {
        readFromFile(path);
    }

    @Override
    public void readFromFile(String filePath){
        StringBuilder contentBuilder = new StringBuilder();

        try (Stream<String> stream = Files.lines( Paths.get(filePath), StandardCharsets.UTF_8))
        {
            stream.forEach(s -> contentBuilder.append(s).append("\n"));
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        this.stringResult = contentBuilder.toString();
    }


    @Override
    public <T> T getData(Object obj, Class<T> tClass) {
        return null;
    }

    public String getStringResult() {
        return stringResult;
    }

    public void setStringResult(String stringResult) {
        this.stringResult = stringResult;
    }
}
