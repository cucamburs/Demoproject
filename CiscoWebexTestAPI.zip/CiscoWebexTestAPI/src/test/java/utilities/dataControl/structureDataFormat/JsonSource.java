package utilities.dataControl.structureDataFormat;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import utilities.dataControl.dataSource.DataSource;

public class JsonSource extends DataSource {

    @Override
    public <T> T getData(Object obj, Class<T> tClass) {
        Gson gson = new Gson();
        return (T) gson.fromJson((String) obj, tClass);
    }
}
