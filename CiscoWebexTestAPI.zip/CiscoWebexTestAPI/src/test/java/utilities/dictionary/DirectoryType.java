package utilities.dictionary;

public enum DirectoryType {
    repositoryPath,
    directory,
    cmd
}
