package utilities.dictionary;

public enum ParamType {
    address
}
