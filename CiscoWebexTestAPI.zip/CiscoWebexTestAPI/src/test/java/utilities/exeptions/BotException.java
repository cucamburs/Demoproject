package utilities.exeptions;

import java.io.IOException;

public class BotException extends IOException {

    public void getMessage(String botEmail) {
        System.out.println("Bot with email \"" + botEmail + "\" already exist");
    }


}
