package utilities.exeptions;

import java.io.IOException;

public class IncorrectUserParamException extends IOException {
    public IncorrectUserParamException(String message) {
        super(message);
    }
}
