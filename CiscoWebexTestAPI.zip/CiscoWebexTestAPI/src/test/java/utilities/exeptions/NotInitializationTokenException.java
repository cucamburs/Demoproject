package utilities.exeptions;

public class NotInitializationTokenException extends  Exception{


    public NotInitializationTokenException(String message) {
        super(message);
    }
}
