package utilities.exeptions;

import utilities.dictionary.Applications;

public class NullParamException extends Exception{

        public NullParamException(String message) {
            super(message);

        }
}
